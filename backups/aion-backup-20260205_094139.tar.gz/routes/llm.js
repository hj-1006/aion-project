const express = require('express');
const llmService = require('../services/llmService');
const router = express.Router();

router.post('/query', async (req, res) => {
  try {
    const { question, summarize } = req.body || {};
    if (!question || typeof question !== 'string') {
      return res.status(400).json({ success: false, message: 'question(문자열)이 필요합니다.' });
    }
    const result = await llmService.queryNetwork(question.trim(), { summarize: summarize !== false });
    res.json(result);
  } catch (err) {
    console.error('LLM query error:', err);
    res.status(500).json({ success: false, error: err.message, output: null, summary: null });
  }
});

router.get('/hosts', async (req, res) => {
  try {
    const hosts = await llmService.getAvailableHosts();
    res.json({ success: true, hosts });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, hosts: [] });
  }
});

module.exports = router;
