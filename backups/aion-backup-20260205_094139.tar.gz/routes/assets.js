const express = require('express');
const db = require('../config/db');
const router = express.Router();

router.get('/', async (req, res) => {
  try {
    const rows = await db.query('SELECT id, device_id, type, location, role, ip, created_at FROM assets ORDER BY device_id');
    res.json({ success: true, assets: rows });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: err.message });
  }
});

module.exports = router;
