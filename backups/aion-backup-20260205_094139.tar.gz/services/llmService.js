const axios = require('axios');
const ansibleService = require('./ansibleService');
const db = require('../config/db');

const OLLAMA_URL = (process.env.OLLAMA_URL || 'http://localhost:11434').replace(/\/$/, '');
const OLLAMA_MODEL = process.env.OLLAMA_MODEL || 'llama3';

const COMMAND_HINTS = [
  'show ip interface brief',
  'show ip int brief',
  'show interfaces',
  'show ip route',
  'show vlan',
  'show running-config',
  'show version',
  'show ip protocols',
  'show cdp neighbors',
  'show arp'
];

async function getAvailableHosts() {
  try {
    const rows = await db.query('SELECT device_id FROM assets ORDER BY device_id');
    if (rows && rows.length > 0) return rows.map(r => r.device_id);
  } catch (_) {}
  return ['Router2', 'Router3'];
}

/**
 * Ask Ollama (LLaMA) to interpret user question -> { hostname, command }
 */
async function interpretQuestion(question, availableHosts) {
  const hosts = availableHosts.length ? availableHosts.join(', ') : 'Router2, Router3';
  const prompt = `You are a network automation assistant. The user will ask about network device info in Korean or English.

Available devices (hostnames): ${hosts}

Allowed Cisco IOS show commands (reply with EXACT text): ${COMMAND_HINTS.join(', ')}

User question: "${(question || '').trim()}"

Reply with ONLY a JSON object, no other text:
{"hostname": "device_name", "command": "show ..."}

Examples:
- "Router2 포트 정보" -> {"hostname": "Router2", "command": "show ip interface brief"}
- "Router3의 IP랑 VLAN 보여줘" -> first request interfaces: {"hostname": "Router3", "command": "show ip interface brief"} or vlan: {"hostname": "Router3", "command": "show vlan"}
- "라우터2 설정" -> {"hostname": "Router2", "command": "show running-config"}

If you cannot determine device or command, use: {"hostname": "Router2", "command": "show ip interface brief"}`;

  try {
    const res = await axios.post(`${OLLAMA_URL}/api/generate`, {
      model: OLLAMA_MODEL,
      prompt,
      stream: false,
      options: { temperature: 0.2 }
    }, { timeout: 60000 });
    const text = (res.data && res.data.response) || '';
    const jsonMatch = text.match(/\{[\s\S]*?\}/);
    if (!jsonMatch) {
      return { hostname: 'Router2', command: 'show ip interface brief', raw: text };
    }
    const parsed = JSON.parse(jsonMatch[0]);
    const hostname = (parsed.hostname || 'Router2').toString().trim();
    const command = (parsed.command || 'show ip interface brief').toString().trim();
    if (!ansibleService.isCommandAllowed(command)) {
      return { hostname, command: 'show ip interface brief', raw: text };
    }
    return { hostname, command, raw: text };
  } catch (err) {
    console.error('LLM interpret error:', err.message);
    return { hostname: 'Router2', command: 'show ip interface brief', error: err.message };
  }
}

/**
 * Optional: summarize Ansible output in natural language via LLM
 */
async function summarizeOutput(question, command, outputText) {
  const prompt = `네트워크 장비 조회 결과를 요약해주세요. 2~3문장으로 한국어로 답변.

질문: ${question}
실행 명령: ${command}

출력:
${(outputText || '').slice(0, 2000)}

요약:`;

  try {
    const res = await axios.post(`${OLLAMA_URL}/api/generate`, {
      model: OLLAMA_MODEL,
      prompt,
      stream: false,
      options: { temperature: 0.3 }
    }, { timeout: 30000 });
    return (res.data && res.data.response) || outputText;
  } catch (err) {
    return outputText;
  }
}

/**
 * Full flow: user question -> LLM interpret -> Ansible run -> optional LLM summary
 */
async function queryNetwork(question, options = {}) {
  const { summarize = true } = options;
  const hosts = await getAvailableHosts();
  const { hostname, command, error: interpretError } = await interpretQuestion(question, hosts);
  if (interpretError) {
    return { success: false, error: `LLM 해석 실패: ${interpretError}`, hostname: null, command: null, output: null, summary: null };
  }
  const ansibleResult = await ansibleService.runShowCommand(hostname, command);
  if (!ansibleResult.success) {
    return {
      success: false,
      error: ansibleResult.error || 'Ansible 실행 실패',
      hostname,
      command,
      output: ansibleResult.stdout || null,
      summary: null
    };
  }
  const outputText = (ansibleResult.stdout || '').trim();
  let summary = null;
  if (summarize && outputText) {
    summary = await summarizeOutput(question, command, outputText);
  }
  return {
    success: true,
    hostname,
    command,
    output: outputText,
    summary: summary || outputText.slice(0, 500)
  };
}

module.exports = { interpretQuestion, summarizeOutput, queryNetwork, getAvailableHosts };
