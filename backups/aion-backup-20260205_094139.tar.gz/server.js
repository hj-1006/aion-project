require('dotenv').config();
const express = require('express');
const session = require('express-session');
const bodyParser = require('body-parser');
const path = require('path');
const authRoutes = require('./routes/auth');
const syslogRoutes = require('./routes/syslog');
const telemetryRoutes = require('./routes/telemetry');
const assetsRoutes = require('./routes/assets');
const llmRoutes = require('./routes/llm');
const requireAuth = require('./middleware/requireAuth');
const authService = require('./services/authService');
const { startSyslogServer } = require('./services/syslogServer');
const { startTelemetryCollector } = require('./services/telemetryCollector');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(
  session({
    secret: process.env.SESSION_SECRET || 'aion-session-secret',
    resave: false,
    saveUninitialized: false,
    name: 'aion.sid',
    cookie: { httpOnly: true, maxAge: 24 * 60 * 60 * 1000 }
  })
);

// Public: login page only
app.get('/', (req, res) => {
  if (req.session && req.session.user) return res.redirect('/dashboard');
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// API auth (no auth required for login)
app.use('/api/auth', authRoutes);

// Protected API
app.use('/api/syslog', requireAuth, syslogRoutes);
app.use('/api/telemetry', requireAuth, telemetryRoutes);
app.use('/api/assets', requireAuth, assetsRoutes);
app.use('/api/llm', requireAuth, llmRoutes);

// Protected pages (auth required) — 확장자 없이 URL 제공
app.get('/dashboard', requireAuth, (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'dashboard.html'));
});
app.get('/syslog', requireAuth, (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'syslog.html'));
});
app.get('/telemetry', requireAuth, (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'telemetry.html'));
});
app.get('/ansible-dummy', requireAuth, (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'ansible-dummy.html'));
});
app.get('/llm-query', requireAuth, (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'llm-query.html'));
});
// .html 요청은 확장자 없는 URL로 리다이렉트
app.get('/dashboard.html', (req, res) => res.redirect(301, '/dashboard'));
app.get('/syslog.html', (req, res) => res.redirect(301, '/syslog'));
app.get('/telemetry.html', (req, res) => res.redirect(301, '/telemetry'));
app.get('/ansible-dummy.html', (req, res) => res.redirect(301, '/ansible-dummy'));
app.get('/llm-query.html', (req, res) => res.redirect(301, '/llm-query'));
app.use(express.static(path.join(__dirname, 'public'), { index: false }));

// Prometheus metrics (optional)
if (process.env.PROMETHEUS_METRICS_ENABLED === 'true') {
  try {
    const { register, collectDefaultMetrics } = require('prom-client');
    collectDefaultMetrics();
    app.get('/metrics', async (req, res) => {
      res.set('Content-Type', register.contentType);
      const metrics = await register.metrics();
      res.end(metrics);
    });
  } catch (e) {
    // prom-client optional
  }
}

app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({ success: false, message: err.message || '서버 오류' });
});

async function start() {
  try {
    await authService.ensureDefaultAdmin();
  } catch (e) {
    console.warn('DB not ready, skipping default admin:', e.message);
  }
  startSyslogServer();
  startTelemetryCollector();
  app.listen(PORT, () => {
    console.log(`AION Mission Control http://localhost:${PORT}`);
  });
}

start().catch((err) => {
  console.error('Start failed:', err);
  process.exit(1);
});
