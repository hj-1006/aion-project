// 더미 데이터 (DB/Telemetry에 데이터가 없을 때만 사용)
const DUMMY_DEVICES = [
  { device_id: 'Router2', cpu_pct: 24, mem_pct: 62, temp_c: 42 },
  { device_id: 'Router3', cpu_pct: 18, mem_pct: 55, temp_c: 38 },
  { device_id: 'Switch4', cpu_pct: 31, mem_pct: 48, temp_c: 45 }
];

function escapeHtml(s) {
  const div = document.createElement('div');
  div.textContent = s;
  return div.innerHTML;
}

function numOrDash(v) {
  if (v === undefined || v === null || Number.isNaN(v)) return '-';
  return Number(v);
}
function pctWidth(v) {
  if (v === undefined || v === null || Number.isNaN(v)) return 0;
  return Math.min(100, Math.max(0, Number(v)));
}
function tempWidth(v) {
  if (v === undefined || v === null || Number.isNaN(v)) return 0;
  return Math.min(100, (Number(v) / 60) * 100);
}

function renderCard(d) {
  const cpu = d.cpu_pct;
  const mem = d.mem_pct;
  const temp = d.temp_c;
  return `
    <div class="metric-card">
      <div class="device">${escapeHtml(d.device_id)}</div>
      <div class="gauge-wrap">
        <div class="label">CPU 사용률</div>
        <div class="gauge-bar"><div class="gauge-fill cpu" style="width:${pctWidth(cpu)}%"></div></div>
        <div class="value">${numOrDash(cpu)}%</div>
      </div>
      <div class="gauge-wrap">
        <div class="label">메모리 사용률</div>
        <div class="gauge-bar"><div class="gauge-fill mem" style="width:${pctWidth(mem)}%"></div></div>
        <div class="value">${numOrDash(mem)}%</div>
      </div>
      <div class="gauge-wrap">
        <div class="label">온도</div>
        <div class="gauge-bar"><div class="gauge-fill temp" style="width:${tempWidth(temp)}%"></div></div>
        <div class="value">${numOrDash(temp)} °C</div>
      </div>
    </div>
  `;
}

async function loadUser() {
  try {
    const res = await fetch('/api/auth/me', { credentials: 'include' });
    const data = await res.json();
    if (!data.success) { window.location.href = '/'; return; }
    var u = data.user;
    document.getElementById('userName').textContent = (u?.display_name || u?.username || '-') + (u?.email ? ' (' + u.email + ') 님 환영합니다' : '');
  } catch (_) { window.location.href = '/'; }
}
document.getElementById('logoutBtn').addEventListener('click', async () => {
  await fetch('/api/auth/logout', { method: 'POST', credentials: 'include' });
  window.location.href = '/';
});

function buildMetricsFromSnapshots(snapshots, assets) {
  const byDevice = {};
  assets.forEach(a => {
    byDevice[a.device_id] = { device_id: a.device_id, cpu_pct: null, mem_pct: null, temp_c: null };
  });
  const sorted = [...snapshots].sort((a, b) => new Date(b.collected_at) - new Date(a.collected_at));
  const seen = {};
  sorted.forEach(s => {
    const deviceId = s.device_id;
    const key = deviceId + '-' + s.metric_type;
    if (seen[key]) return;
    seen[key] = true;
    if (!byDevice[deviceId]) byDevice[deviceId] = { device_id: deviceId, cpu_pct: null, mem_pct: null, temp_c: null };
    const val = typeof s.value_json === 'string' ? (() => { try { return JSON.parse(s.value_json); } catch (_) { return {}; } })() : (s.value_json || {});
    const m = byDevice[deviceId];
    if (s.metric_type === 'cpu' && val.cpu_pct != null) m.cpu_pct = val.cpu_pct;
    if (s.metric_type === 'mem' && val.mem_pct != null) m.mem_pct = val.mem_pct;
    if (s.metric_type === 'temp' && val.temp_c != null) m.temp_c = val.temp_c;
  });
  return Object.values(byDevice);
}

async function loadMetrics() {
  const grid = document.getElementById('metricGrid');
  const notice = document.getElementById('dummyNotice');
  const label = document.getElementById('dataSourceLabel');
  if (notice) notice.textContent = 'DB Telemetry·자산에서 실제값을 불러오는 중…';
  if (label) label.textContent = '';
  try {
    const [snapRes, assetsRes] = await Promise.all([
      fetch('/api/telemetry/snapshots?limit=500', { credentials: 'include' }),
      fetch('/api/assets', { credentials: 'include' })
    ]);
    const snapData = await snapRes.json();
    const assetsData = await assetsRes.json();
    const snapshots = snapData.success ? (snapData.snapshots || []) : [];
    const assets = assetsData.success ? (assetsData.assets || []) : [];
    const list = buildMetricsFromSnapshots(snapshots, assets);
    if (list.length > 0) {
      grid.innerHTML = list.map(renderCard).join('');
      if (notice) notice.textContent = '아래 값은 DB Telemetry 스냅샷에서 불러온 실제 데이터입니다. 자산 등록 후 수집기가 돌면 갱신됩니다.';
      if (label) label.textContent = '실제 데이터 (' + list.length + '개 장비)';
    } else {
      grid.innerHTML = DUMMY_DEVICES.map(renderCard).join('');
      if (notice) notice.textContent = '아래 값은 더미 데이터입니다. 자산을 등록하고 Telemetry 수집이 돌면 실제 CPU/메모리/온도가 표시됩니다.';
      if (label) label.textContent = '더미 데이터';
    }
  } catch (_) {
    grid.innerHTML = DUMMY_DEVICES.map(renderCard).join('');
    if (notice) notice.textContent = '아래 값은 더미 데이터입니다. API 연결 실패 시 표시됩니다.';
    if (label) label.textContent = '연결 실패';
  }
}

document.getElementById('btnRefresh').addEventListener('click', loadMetrics);

loadUser();
loadMetrics();
