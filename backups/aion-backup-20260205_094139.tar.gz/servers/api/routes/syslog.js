const express = require('express');
const queryClient = require('../lib/queryClient');
const logger = require('../../../lib/logger');
const router = express.Router();

router.get('/events', async (req, res) => {
  try {
    const limit = req.query.limit || '100';
    const severity = req.query.severity || null;
    const assetId = req.query.asset_id || null;
    const events = await queryClient.getSyslogEvents({ limit, severity, asset_id: assetId });
    res.json({ success: true, events });
  } catch (err) {
    logger.error('syslog/events: ' + (err.message || err), { stack: err.stack });
    res.status(500).json({ success: false, message: err.message });
  }
});

router.get('/events/count', async (req, res) => {
  try {
    const count = await queryClient.getSyslogEventsCount();
    res.json({ success: true, count });
  } catch (err) {
    logger.error('syslog/events/count: ' + (err.message || err));
    res.status(500).json({ success: false, message: err.message });
  }
});

module.exports = router;
