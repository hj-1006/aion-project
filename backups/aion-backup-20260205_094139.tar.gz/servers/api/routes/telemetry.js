const express = require('express');
const queryClient = require('../lib/queryClient');
const logger = require('../../../lib/logger');
const router = express.Router();

router.get('/snapshots', async (req, res) => {
  try {
    const params = { limit: req.query.limit, asset_id: req.query.asset_id, metric_type: req.query.metric_type };
    const snapshots = await queryClient.getTelemetrySnapshots(params);
    res.json({ success: true, snapshots });
  } catch (err) {
    logger.error('telemetry: ' + (err.message || err), { stack: err.stack });
    res.status(500).json({ success: false, message: err.message });
  }
});

router.get('/assets', async (req, res) => {
  try {
    const assets = await queryClient.getAssets();
    res.json({ success: true, assets });
  } catch (err) {
    logger.error('telemetry: ' + (err.message || err), { stack: err.stack });
    res.status(500).json({ success: false, message: err.message });
  }
});

router.get('/snapshots/count', async (req, res) => {
  try {
    const count = await queryClient.getTelemetrySnapshotsCount();
    res.json({ success: true, count });
  } catch (err) {
    logger.error('telemetry: ' + (err.message || err), { stack: err.stack });
    res.status(500).json({ success: false, message: err.message });
  }
});

module.exports = router;
