const express = require('express');
const queryClient = require('../lib/queryClient');
const router = express.Router();

router.get('/', async (req, res) => {
  try {
    const assets = await queryClient.getAssets();
    res.json({ success: true, assets });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: err.message });
  }
});

module.exports = router;
