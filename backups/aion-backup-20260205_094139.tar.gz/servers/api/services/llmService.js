const path = require('path');
const { spawn } = require('child_process');
const ansibleService = require('./ansibleService');
const queryClient = require('../lib/queryClient');
const logger = require('../../../lib/logger');

const PROJECT_ROOT = path.resolve(path.join(__dirname, '../../..'));
const SCRIPTS_DIR = path.join(PROJECT_ROOT, 'scripts');
const LLM_INTERPRET_SCRIPT = path.join(SCRIPTS_DIR, 'llm_interpret.py');
const LLM_SUMMARIZE_SCRIPT = path.join(SCRIPTS_DIR, 'llm_summarize.py');

const OLLAMA_DISABLED = process.env.OLLAMA_DISABLED === 'true';

function runPython(scriptPath, args, env) {
  return new Promise((resolve, reject) => {
    const pythonCmd = process.platform === 'win32' ? 'python' : 'python3';
    const proc = spawn(pythonCmd, ['-u', scriptPath].concat(args), {
      cwd: PROJECT_ROOT,
      env: { ...process.env, PYTHONUNBUFFERED: '1', ...env },
      stdio: ['ignore', 'pipe', 'pipe']
    });
    let stdout = '';
    let stderr = '';
    proc.stdout.setEncoding('utf8');
    proc.stderr.setEncoding('utf8');
    proc.stdout.on('data', (chunk) => { stdout += chunk; });
    proc.stderr.on('data', (chunk) => {
      stderr += chunk;
      logger.info('Python: ' + chunk.toString().trim());
    });
    proc.on('close', (code) => {
      if (code !== 0) logger.warn('Python 종료 코드: ' + code + ', stderr: ' + stderr.slice(0, 200));
      resolve({ code, stdout, stderr });
    });
    proc.on('error', (err) => {
      if (err.code === 'ENOENT' && pythonCmd === 'python3') {
        runPython(scriptPath, args, env).then(resolve).catch(reject);
        return;
      }
      reject(err);
    });
  });
}

async function getAvailableHosts() {
  try {
    const assets = await queryClient.getAssets();
    if (assets && assets.length > 0) return assets.map(r => r.device_id);
  } catch (_) {}
  return ['Router2', 'Router3'];
}

/** 질문 → hostname, command, action 해석. Node는 Ollama 호출 안 함. Python만 실행. */
async function interpretQuestion(question, availableHosts) {
  if (OLLAMA_DISABLED) return { hostname: 'Router2', command: 'show ip interface brief', error: 'Ollama 비활성화됨 (OLLAMA_DISABLED=true)' };
  const reachableHostsJson = JSON.stringify(Array.isArray(availableHosts) ? availableHosts : []);
  try {
    const { code, stdout, stderr } = await runPython(LLM_INTERPRET_SCRIPT, [question, reachableHostsJson]);
    const parsed = JSON.parse(stdout.trim() || '{}');
    if (parsed.error) return { hostname: 'Router2', command: 'show ip interface brief', error: parsed.error };
    const hostname = (parsed.hostname || 'Router2').toString().trim();
    const action = (parsed.action || '').toString().trim().toLowerCase();
    const command = (parsed.command || 'show ip interface brief').toString().trim();
    if (action === 'cpu_memory' || action === 'temperature') return { hostname, action, raw: parsed.raw };
    if (!ansibleService.isCommandAllowed(command)) return { hostname, command: 'show ip interface brief', raw: parsed.raw };
    return { hostname, command, raw: parsed.raw };
  } catch (err) {
    const msg = err.message || String(err);
    logger.warn('LLM interpret error: ' + msg);
    return { hostname: 'Router2', command: 'show ip interface brief', error: msg };
  }
}

/** 장비 출력 → 한국어 요약. Node는 Ollama 호출 안 함. Python만 실행. */
async function summarizeOutput(question, command, outputText) {
  const payload = JSON.stringify({ question, command, outputText: (outputText || '').slice(0, 2000) });
  try {
    const { stdout } = await runPython(LLM_SUMMARIZE_SCRIPT, [payload]);
    return (stdout && stdout.trim()) || outputText;
  } catch (err) {
    return outputText;
  }
}

async function queryNetwork(question, options = {}) {
  const { summarize = true } = options;
  const hosts = await getAvailableHosts();
  const interpreted = await interpretQuestion(question, hosts);
  const { hostname, command, action, error: interpretError } = interpreted;
  if (interpretError) {
    return { success: false, error: 'LLM 해석 실패: ' + interpretError, hostname: null, command: null, output: null, summary: null };
  }
  let ansibleResult;
  if (action === 'cpu_memory') {
    ansibleResult = await ansibleService.runGatherCpuMemory(hostname);
  } else if (action === 'temperature') {
    ansibleResult = await ansibleService.runGatherTemperature(hostname);
  } else {
    ansibleResult = await ansibleService.runShowCommand(hostname, command || 'show ip interface brief');
  }
  const displayCommand = command || (action === 'cpu_memory' ? 'CPU/메모리 수집' : action === 'temperature' ? '온도/환경 수집' : '');
  if (!ansibleResult.success) {
    return { success: false, error: ansibleResult.error || 'Ansible 실행 실패', hostname, command: displayCommand, output: ansibleResult.stdout || null, summary: null };
  }
  const outputText = (ansibleResult.stdout || '').trim();
  let summary = null;
  if (summarize && outputText) summary = await summarizeOutput(question, displayCommand, outputText);
  return { success: true, hostname, command: displayCommand, output: outputText, summary: summary || outputText.slice(0, 500) };
}

module.exports = { interpretQuestion, summarizeOutput, queryNetwork, getAvailableHosts };
