const path = require('path');
const fs = require('fs');
require('dotenv').config({ path: path.join(__dirname, '../../.env') });
const express = require('express');
const logger = require('../../lib/logger');
const session = require('express-session');
const bodyParser = require('body-parser');
const authRoutes = require('./routes/auth');
const syslogRoutes = require('./routes/syslog');
const telemetryRoutes = require('./routes/telemetry');
const assetsRoutes = require('./routes/assets');
const llmRoutes = require('./routes/llm');
const mailRoutes = require('./routes/mail');
const accountsRoutes = require('./routes/accounts');
const dbRoutes = require('./routes/db');
const requireAuth = require('./middleware/requireAuth');
const requireMailUser = require('./middleware/requireMailUser');
const requireAdmin = require('./middleware/requireAdmin');
const authService = require('./services/authService');
const { startSyslogServer } = require('./services/syslogServer');
const { startTelemetryCollector } = require('./services/telemetryCollector');

const app = express();
const PORT = process.env.PORT || 3001;
const DEBUG_MAIL_LOG = path.join(__dirname, '../../debug-mail.log');

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(session({
  secret: process.env.SESSION_SECRET || 'aion-session-secret',
  resave: false,
  saveUninitialized: false,
  name: 'aion.sid',
  cookie: { httpOnly: true, maxAge: 24 * 60 * 60 * 1000 }
}));

app.use('/api/auth', authRoutes);
app.use('/api/syslog', requireAuth, syslogRoutes);
app.use('/api/telemetry', requireAuth, telemetryRoutes);
app.use('/api/assets', requireAuth, assetsRoutes);
app.use('/api/llm', requireAuth, llmRoutes);
app.use('/api/mail', (req, res, next) => {
  logger.info('[debug] /api/mail request', { method: req.method, path: req.path });
  try { fs.appendFileSync(DEBUG_MAIL_LOG, JSON.stringify({ t: Date.now(), method: req.method, path: req.path }) + '\n'); } catch (_) {}
  next();
});
app.use('/api/mail', requireAuth, requireMailUser, mailRoutes);
app.use('/api/accounts', requireAuth, requireAdmin, accountsRoutes);
app.use('/api/db', requireAuth, dbRoutes);

app.get('/health', (req, res) => res.json({ ok: true, service: 'api' }));

if (process.env.PROMETHEUS_METRICS_ENABLED === 'true') {
  try {
    const { register, collectDefaultMetrics } = require('prom-client');
    collectDefaultMetrics();
    app.get('/metrics', async (req, res) => {
      res.set('Content-Type', register.contentType);
      res.end(await register.metrics());
    });
  } catch (e) {}
}

app.use((err, req, res, next) => {
  logger.error(err.message || err, { stack: err.stack });
  res.status(500).json({ success: false, message: err.message || '서버 오류' });
});

async function start() {
  try {
    await authService.ensureDefaultAdmin();
  } catch (e) {
    logger.warn('Query server not ready, skipping default admin: ' + e.message);
  }
  startSyslogServer();
  startTelemetryCollector();
  app.listen(PORT, () => {
    logger.info('AION API Server http://localhost:' + PORT);
  });
}

start().catch((err) => {
  logger.error('Start failed: ' + (err.message || err), { stack: err.stack });
  process.exit(1);
});
