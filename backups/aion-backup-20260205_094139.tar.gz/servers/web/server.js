const path = require('path');
const fs = require('fs');
const http = require('http');
const https = require('https');
require('dotenv').config({ path: path.join(__dirname, '../../.env') });
const express = require('express');
const { createProxyMiddleware } = require('http-proxy-middleware');
const PUBLIC_DIR = path.join(__dirname, '../../public');
const API_SERVER_URL = process.env.API_SERVER_URL || 'http://localhost:3001';
const PORT_HTTP = process.env.WEB_PORT || process.env.PORT || 80;
const PORT_HTTPS = process.env.WEB_PORT_HTTPS || 443;
const CERTS_DIR = path.join(__dirname, '../../certs');

const app = express();

app.use('/api', createProxyMiddleware({
  target: API_SERVER_URL,
  changeOrigin: true,
  onProxyReq: (proxyReq, req) => {
    const cookie = req.headers.cookie;
    if (cookie) proxyReq.setHeader('Cookie', cookie);
  }
}));

app.get('/', (req, res) => {
  res.sendFile(path.join(PUBLIC_DIR, 'index.html'));
});
// 확장자 없이 URL 제공 (.html 파일명 숨김)
app.get('/dashboard', (req, res) => res.sendFile(path.join(PUBLIC_DIR, 'dashboard.html')));
app.get('/syslog', (req, res) => res.sendFile(path.join(PUBLIC_DIR, 'syslog.html')));
app.get('/telemetry', (req, res) => res.sendFile(path.join(PUBLIC_DIR, 'telemetry.html')));
app.get('/ansible-dummy', (req, res) => res.sendFile(path.join(PUBLIC_DIR, 'ansible-dummy.html')));
app.get('/llm-query', (req, res) => res.sendFile(path.join(PUBLIC_DIR, 'llm-query.html')));
app.get('/data-management', (req, res) => res.sendFile(path.join(PUBLIC_DIR, 'data-management.html')));
app.get('/mail', (req, res) => res.sendFile(path.join(PUBLIC_DIR, 'mail.html')));
app.get('/accounts', (req, res) => res.sendFile(path.join(PUBLIC_DIR, 'accounts.html')));
// .html 요청은 확장자 없는 URL로 리다이렉트 (주소창 정리)
app.get('/dashboard.html', (req, res) => res.redirect(301, '/dashboard'));
app.get('/syslog.html', (req, res) => res.redirect(301, '/syslog'));
app.get('/telemetry.html', (req, res) => res.redirect(301, '/telemetry'));
app.get('/ansible-dummy.html', (req, res) => res.redirect(301, '/ansible-dummy'));
app.get('/llm-query.html', (req, res) => res.redirect(301, '/llm-query'));
app.get('/data-management.html', (req, res) => res.redirect(301, '/data-management'));
app.get('/mail.html', (req, res) => res.redirect(301, '/mail'));
app.get('/accounts.html', (req, res) => res.redirect(301, '/accounts'));
app.use(express.static(PUBLIC_DIR, { index: false }));

const HOST = '0.0.0.0';

http.createServer(app).listen(PORT_HTTP, HOST, () => {
  console.log('AION Web Server http://' + HOST + ':' + PORT_HTTP + ' (API proxy -> ' + API_SERVER_URL + ')');
});

const certPath = path.join(CERTS_DIR, 'cert.pem');
const keyPath = path.join(CERTS_DIR, 'key.pem');
if (fs.existsSync(certPath) && fs.existsSync(keyPath)) {
  const httpsOptions = {
    cert: fs.readFileSync(certPath),
    key: fs.readFileSync(keyPath)
  };
  https.createServer(httpsOptions, app).listen(PORT_HTTPS, HOST, () => {
    console.log('AION Web Server https://' + HOST + ':' + PORT_HTTPS);
  });
} else {
  console.log('HTTPS 비활성: certs/cert.pem, certs/key.pem 없음 (443 미사용)');
}