const express = require('express');
const db = require('../config/db');
const logger = require('../../../lib/logger');
const router = express.Router();

router.get('/', async (req, res) => {
  try {
    const rows = await db.query('SELECT id, device_id, type, location, role, ip, created_at FROM assets ORDER BY device_id');
    res.json({ success: true, assets: rows });
  } catch (err) {
    logger.error('assets GET /: ' + (err.message || err), { stack: err.stack });
    res.status(500).json({ success: false, error: err.message });
  }
});

router.get('/list-for-telemetry', async (req, res) => {
  try {
    const rows = await db.query('SELECT id, device_id, ip FROM assets ORDER BY device_id LIMIT 20');
    res.json({ success: true, assets: rows });
  } catch (err) {
    logger.error('assets GET /list-for-telemetry: ' + (err.message || err));
    res.status(500).json({ success: false, error: err.message });
  }
});

module.exports = router;
