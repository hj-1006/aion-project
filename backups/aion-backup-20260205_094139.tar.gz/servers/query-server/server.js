const path = require('path');
require('dotenv').config({ path: path.join(__dirname, '../../.env') });
const express = require('express');
const logger = require('../../lib/logger');
const bodyParser = require('body-parser');
const usersRoutes = require('./routes/users');
const syslogRoutes = require('./routes/syslog');
const telemetryRoutes = require('./routes/telemetry');
const assetsRoutes = require('./routes/assets');
const dbRoutes = require('./routes/db');
const mailLogRoutes = require('./routes/mailLog');

const app = express();
const PORT = process.env.PORT || 3002;

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

app.use('/users', usersRoutes);
app.use('/syslog', syslogRoutes);
app.use('/telemetry', telemetryRoutes);
app.use('/assets', assetsRoutes);
app.use('/db', dbRoutes);
app.use('/mail-log', mailLogRoutes);

app.get('/health', (req, res) => res.json({ ok: true, service: 'query-server' }));

app.use((err, req, res, next) => {
  logger.error(err.message || err, { stack: err.stack });
  res.status(500).json({ success: false, error: err.message });
});

app.listen(PORT, () => {
  logger.info('AION Query Server (MySQL) http://localhost:%s', PORT);
});
